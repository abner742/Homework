

#-*- coding: utf-8 -*-
from socket import *
import threading # 引入线程模块
import os
import webbrowser


# 针对线程使用编写的函数
def Server(tcpClisock, addr):
    BUFSIZE = 1024*300 # 将缓冲区大小设置为 1KB。listen()方法的参数是在连接被转接或拒绝之前，传入连接请求的最大数
    print('connected from:', addr) 
    rec = tcpClisock.recv(BUFSIZE)
    data = rec.decode()


    # 当服务器因为网络问题未收到返回信息时，直接退出
    if len(data) == 0:
        tcpClisock.close()
        return 
    print("***************************************************\n")
    print("data")
    print(data)
    HOME_DIR = os.getcwd() # 服务器端可访问的文件目录
    index = 4 # 检索文件的搜索路径
    # 找到路径
    while data[index] != ' ':
        index += 1
    # 如果检索文件为空，则导向访问成功的页面,输入其他的都是错的
    if index == 5 : direction = os.path.join(HOME_DIR, "Index.html") 
    else: direction = os.path.join(HOME_DIR, data[5 : index]) # 拼接出完整的路径
    print("direction: "+direction)
    f=open(direction,'rb')
    # 打印出了完整的路径,现在要从这个路径读文件,然后打包发送到前端
    html_data = f.read()
    tcpClisock.sendall(bytes("HTTP/1.1 200 OK\r\n\r\n","utf8"))
    tcpClisock.sendall(html_data) # 返回给客户端浏览器成功的页面
        # sendall 函数只可发送字节类型，对字符串数据进行转换
    tcpClisock.close() # 关闭专门针对一个客户机程序创建的新套接字
    # 如果路径不存在，返回失败页面

    # FAIL_PAGE = "HTTP/1.1 404 NotFound\r\n\r\n" + open(os.path.join(HOME_DIR, "Fail.html")).read()
    # tcpClisock.sendall(FAIL_PAGE.encode()) # 返回给客户端浏览器失败的页面
    # # sendall 函数只可发送字节类型，对字符串数据进行转换
    # tcpClisock.close() # 关闭专门针对一个客户机程序创建的新套接字
    

if __name__ =='__main__': 
    HOST = "" # HOST 变量是空白的，这是对 bind()方法的标识，表示它可以使用任何可用的地址  # 此程序在什么主机上运行，就会为该主机的IP地址
    PORT = 8080  # 随机的端口号，并且该端口号似乎没有被使用或被系统保留
    ADDR = (HOST, PORT) # 地址 = 主机名 + 端口号
    tcpSersock = socket(AF_INET, SOCK_STREAM) # 创建一个套接字对象
    tcpSersock.bind(ADDR) # 将套接字绑定到服务器地址  相当于欢迎套接字，且绑定的是源ip地址以及源端口号。始终欢迎别的套接字的申请接入
    tcpSersock.listen(5) # 启用服务器的监听，调用参数是在连接被转接或拒绝之前，传入连接请求的最大数，此处说明允许传入链接请求数为5
    print("waiting for connection......\n")                  
    while True:  #进入无限循环
        tcpClisock, addr = tcpSersock.accept() 
        # 调用 accept()函数之后，就开启了一个简单的（单线程）服务器，它会等待客户端的连接。
        # 默认情况下，accept()是阻塞的，这意味着执行将被暂停，直到一个连接到达。
        # 当一个传入的请求到达时，服务器会创建一个新的通信端口来直接与客户端进行通信，再次空出主要的端口
        # 使用新的客户端套接字能够空出主线（原始服务器套接字）以使其能够接受新的客户端连接。	
        thread = threading.Thread(target=Server, args=(tcpClisock, addr))  
        thread.start() # 开始执行该线程

    tcpSersock.close() # 这种情况永远也不会碰到,因为在此程序中，服务器始终在一个无限循环中运行
        			   # 但如果写了一个处理程序，当一个处理程序检测到一些外部条件时，服务器就应该关闭。应该调用一个 close()方
