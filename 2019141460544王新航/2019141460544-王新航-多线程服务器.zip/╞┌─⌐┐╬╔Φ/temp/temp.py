#coding:utf-8
import socket
 
def process_request(request):
    request.recv(1024)#读取接受的字节
    request.send("HTTP/1.1 200 OK\r\n".encode())#返回请求状态码
    request.send("Content-Type:text/html\r\n\r\n".encode())#返回数据格式解析类型
    request.send("<h1>it's worked</h1>".encode())#返回一个服务器数据格式
 
def main():
    sock = socket.socket(socket.AF_INET,socket.SOCK_STREAM)#创建一个服务器socket监听
    sock.bind(('localhost',8080))
    sock.listen(5)#设置最大监听数
    while True:
        connection,address = sock.accept()#接受浏览器请求
        process_request(connection)
        connection.close()
if __name__=="__main__":
    main()